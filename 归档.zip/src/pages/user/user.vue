<template>
    <view class="user-box">我的</view>
</template>

<script>
export default {
  name: "user"
}
</script>

<style scoped lang="scss">
.user-box {
  background-color: #FFFFFF;
}
</style>
