<template>
  <view class="curriculum-box">课程</view>
</template>

<script>
export default {
  name: "curriculum"
}
</script>

<style scoped lang="scss">
.curriculum-box {
  background-color: #FFFFFF;
}
</style>