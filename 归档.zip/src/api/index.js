export default {
    basePath: '/api'
};
