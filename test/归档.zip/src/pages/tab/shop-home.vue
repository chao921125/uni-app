<template>
  <view>
    <web-view :src="url"></web-view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      url: 'https://test-swashes.advokate-bj.com'
    };
  }
};
</script>
<style lang="scss" scoped>
</style>
