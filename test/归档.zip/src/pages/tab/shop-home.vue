<template>
  <view>
    <web-view v-if="isDevelopment" :src="url"></web-view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      // 判断是否为测试环境
      isDevelopment: undefined,
      url: ''
    };
  },
  onShow() {
    if (process.env.NODE_ENV === 'development') {
      this.isDevelopment = true;
      this.url = 'https://test-swashes.advokate-bj.com';
    } else {
      this.isDevelopment = false;
      this.url = 'https://swashes.advokate-bj.com';
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
