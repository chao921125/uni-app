<template>
  <view>
    <web-view v-if="hasToken" :src="url"></web-view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      hasToken: false,
      url: ''
    };
  },
  onShow() {
    this.getUrl();
  },
  methods: {
    getUrl() {
      this.$axios
        .get({
          url: `/wx/authorization`
        })
        .then((res) => {
          if (res && (res.code === '0' || res.code === 0)) {
            this.url = res.data;
            this.hasToken = true;
            return;
          }
          this.$uni.showToast(res.message);
        }).catch(() => {
          this.$uni.navigateBack();
        });
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
