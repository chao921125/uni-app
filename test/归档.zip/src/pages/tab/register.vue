<template>
  <view>
    <view v-html="productObj.content">{{productObj.content}}</view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      code: '',
      productObj: {}
    };
  },
  onLoad(option) {
    if (option.code) {
      this.code = option.code;
      this.pageInit();
    }
  },
  methods: {
    pageInit() {
      this.$axios.get({
        url: `/wx/scan`,
        data: {
          code: this.code
        }
      }).then(res => {
        if (res && (res.code === 0 || res.code === '0')) {
          this.productObj = res.data;
          return;
        }
        this.$uni.showToast(res.message);
      });
    }
  }
};
</script>
<style lang="scss" scoped>
</style>
