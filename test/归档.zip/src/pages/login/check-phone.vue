<template>
  <view class="phone-body">
    <image
      src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-me-avatar.png"
      mode="aspectFit"
    />
    <view class="tip">成为诗乐氏安心会员，赢取多种福利好礼</view>
    <button class="auth-btn" open-type="getPhoneNumber" @getphonenumber="getPhoneNumber">立即加入</button>
  </view>
</template>
<script>
import { login } from '@/extend/uni-api.js';
export default {
  data() {
    return {
      code: ''
    };
  },
  onLoad() {
    login().then(res => {
      this.code = res.code;
    });
  },
  methods: {
    getPhoneNumber(e) {
      this.$axios.post({
        url: '/wx/getWxPhone',
        data: {
          code: this.code,
          encryptedData: e.detail.encryptedData,
          iv: e.detail.iv
        }
      }).then(res => {
        if (res && (res.code === '0' || res.code === 0)) {
          let login = this.$store.getters.login;
          login.havePhone = 1;
          this.$store.dispatch('loginId', login);
          this.$uni.navigateTo({
            url: `/pages/tab/buy-medicine`
          });
          return;
        }
        this.$uni.showToast(res.message);
      });
    }
  }

};
</script>
<style lang="scss" scoped>
.phone-body {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: #ffffff;
  overflow: hidden;
  display: flex;
  justify-content: center;
  align-items: center;
  flex-direction: column;
  image {
    width: 160rpx;
    height: 160rpx;
  }
  .tip {
    width: 520rpx;
    font-size: 40rpx;
    font-weight: 500;
    color: #353535;
    text-align: center;
    line-height: 70rpx;
    margin-top: 100rpx;
  }
  .auth-btn {
    padding: 12rpx 84rpx;
    background: #b91126;
    font-size: 26rpx;
    font-weight: 400;
    color: #ffffff;
    margin-top: 196rpx;
    border-radius: 0;
  }
}
</style>
