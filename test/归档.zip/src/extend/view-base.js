/* eslint-disable no-undef */
import Vue from 'vue';
import Stro from '../utils/set-storage';
import { login } from '@/extend/uni-api.js';
const viewBase = Vue.extend({
  data: () => ({
    isIpx: getApp().globalData.isIpx
  }),
  onLoad() {
    login().then(res => {
      return this.$axios.post({
        url: '/wx/login',
        data: {
          code: res.code
        }
      });
    }).then(res => {
      if (res && (res.code === '0' || res.code === 0)) {
        this.$store.dispatch('loginId', res.data);
        // process.env.NODE_ENV === 'development'为开发环境，需显示口令页面
        // 正式环境无需显示口令页面
        if (process.env.NODE_ENV === 'development' && !Stro.getItem('codeMall')) {
          return uni.reLaunch({ url: '/pages/login/check-code' });
        }
        // isUpd为1时代表有用户信息，为2时代表无用户信息
        // if (res.data.isUpd === 2) {
        //   return uni.redirectTo({
        //     url: '/pages/login/login'
        //   });
        // }
        this.pageInit();
        return;
      }
      this.$uni.showToast(res.message);
    });
  },
  methods: {}
});
export default viewBase;
