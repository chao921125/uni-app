'use strict';

import Vue from 'vue';
import Vuex from 'vuex';
import LocalStorage from '@/extend/uni-storage-localstorage';
Vue.use(Vuex);

const store = new Vuex.Store({
  state: {
    login: undefined,
    openId: undefined,
    sessionKey: undefined,
    authorization: undefined,
    havePhone: undefined,
    isUpd: undefined,
    vip: undefined,
    appid: 'wx81aac53adfaf4e69',
    id: undefined,
    unionid: undefined,
    // 积分商城token
    shopToken: undefined
  },
  getters: {
    authorization: state => {
      let authorization = LocalStorage.get('authorization');
      !state.authorization && authorization && (state.authorization = authorization);
      return state.authorization;
    },
    shopToken: state => {
      let shopToken = LocalStorage.get('shopToken');
      !state.shopToken && shopToken && (state.shopToken = shopToken);
      return state.shopToken;
    },
    openId: state => {
      let openId = LocalStorage.get('openId');
      !state.openId && openId && (state.openId = openId);
      return state.openId;
    },
    unionid: state => {
      return state.unionid;
    },
    sessionKey: state => {
      return state.sessionKey;
    },
    appid: state => {
      return state.appid;
    },
    havePhone: state => {
      let havePhone = LocalStorage.get('havePhone');
      !state.havePhone && havePhone && (state.havePhone = havePhone);
      return state.havePhone;
    },
    isUpd: state => {
      let isUpd = LocalStorage.get('isUpd');
      !state.isUpd && isUpd && (state.isUpd = isUpd);
      return state.isUpd;
    },
    vip: state => {
      return state.vip;
    },
    id: state => {
      return state.id;
    },
    login: state => {
      return state.login;
    }
  },
  mutations: {
    loginId(state, data) {
      state.login = data;
      state.openId = data.openId;
      state.unionid = data.unionid;
      state.sessionKey = data.sessionKey;
      state.authorization = data.authorization;
      state.havePhone = data.havePhone;
      state.isUpd = data.isUpd;
      state.vip = data.vip;
      state.id = data.id;
    },
    shopToken(state, shopToken) {
      state.shopToken = shopToken;
    }
  },
  actions: {
    loginId(context, data) {
      LocalStorage.set('data', data);
      context.commit('loginId', data);
    },
    // loginId({ commit }, data) {
    //   commit('loginId', data);
    // },
    authorization(context, authorization) {
      LocalStorage.set('authorization', authorization);
      context.commit('authorization', authorization);
    },
    shopToken(context, shopToken) {
      LocalStorage.set('shopToken', shopToken);
      context.commit('shopToken', shopToken);
    },
    openId(context, openId) {
      LocalStorage.set('openId', openId);
      context.commit('openId', openId);
    },
    isUpd(context, isUpd) {
      LocalStorage.set('isUpd', isUpd);
      context.commit('isUpd', isUpd);
    },
    havePhone(context, havePhone) {
      LocalStorage.set('havePhone', havePhone);
      context.commit('havePhone', havePhone);
    }
  }
});

export default store;
