/**
 * 前端路由白名单
 */
export const routelist = [
  '/pages/tabbar/tabbar-home',
  // 校驗口令
  '/pages/login/check-code',
  // 啟動頁
  '/pages/login/login'
];
