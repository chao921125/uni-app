<template>
  <view>
    <view class="count">
      <view class="header-box">
        <image
          src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-pay-success.png"
          mode="aspectFit"
        />
        <view>支付成功</view>
      </view>
      <view class="info-box">
        <view class="every-info">
          <view class="info-title">下单时间</view>
          <view class="info">{{orderResult.paymentTime}}</view>
        </view>
        <view class="every-info">
          <view class="info-title">订单编号</view>
          <view class="info">{{orderResult.code}}</view>
        </view>
        <view class="every-info">
          <view class="info-title">支付数额</view>
          <view class="info">{{orderResult.totalAmount}} 元</view>
        </view>
        <view class="every-info">
          <view class="info-title">使用积分</view>
          <view class="info info-img">
            {{orderResult.integral}}
            <image
              class="icon"
              src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-icon-coin.png"
              mode="aspectFit"
            />
          </view>
        </view>
        <view class="btn-group">
          <view class="order-btn" @tap="goOrder">查看订单</view>
          <view class="buy-btn" @tap="goHome">继续兑换</view>
        </view>
      </view>
    </view>
  </view>
</template>
<script>
export default {
  data() {
    return {
      // 订单号
      outTradeNo: undefined,
      // 订单信息
      orderResult: {}
    };
  },
  onLoad(option) {
    if (option && option.outTradeNo) {
      this.outTradeNo = option.outTradeNo;
      this.pageInit();
    }
  },
  methods: {
    // 获取支付成功信息
    pageInit() {
      this.$axios.post({
        url: `/wx/order/queryOrder`,
        data: {
          outTradeNo: this.outTradeNo
        }
      }).then(res => {
        if (res && (res.code === '0' || res.code === 0)) {
          this.orderResult = res.data;
          return;
        }
        this.$uni.showToast(res.message);
      });
    },
    // 跳转到积分商城我的页面
    goOrder() {
      this.$uni.navigateTo({
        url: `/pages/tab/shop-me`
      });
    },
    // 跳转到积分商城首页
    goHome() {
      this.$uni.navigateTo({
        url: `/pages/tab/shop-home`
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.count {
  width: calc(100% - 60rpx);
  padding: 0 30rpx;
  height: auto;
  margin: 0 auto;
  .header-box {
    width: 100%;
    padding: 140rpx 0 70rpx 0;
    height: auto;
    display: flex;
    flex-direction: column;
    align-items: center;
    border-bottom: 1rpx solid #cccccc;
    image {
      width: 146rpx;
      height: 146rpx;
    }
    view {
      font-size: 34rpx;
      font-weight: 400;
      color: #000000;
      margin-top: 40rpx;
    }
  }
  .info-box {
    width: 100%;
    height: auto;
    margin-top: 20rpx;
    .every-info {
      width: 100%;
      height: 90rpx;
      display: flex;
      justify-content: space-between;
      align-items: center;
      .info-title {
        width: 180rpx;
        height: auto;
        font-size: 30rpx;
        font-weight: 400;
        color: #000000;
      }
      .info {
        width: calc(100% - 180rpx);
        height: auto;
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        font-size: 30rpx;
        font-weight: 400;
        color: #999999;
        text-align: right;
      }
      .info-img {
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: flex-end;
        .icon {
          width: 40rpx;
          width: 40rpx;
        }
      }
    }
    .btn-group {
      width: 100%;
      height: auto;
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-top: 20rpx;
      view {
        padding: 18rpx 106rpx;
        font-size: 28rpx;
        font-weight: 400;
      }
      .order-btn {
        color: #ffffff;
        text-shadow: 0rpx 0rpx 10rpx rgba(0, 0, 0, 0.3);
        background: #b91126;
        box-shadow: 0rpx 0rpx 10rpx 0rpx rgba(0, 0, 0, 0.3);
      }
      .buy-btn {
        border: 2rpx solid #b91126;
        color: #b91126;
      }
    }
  }
}
</style>
