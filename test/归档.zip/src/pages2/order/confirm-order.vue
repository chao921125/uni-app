<template>
  <view>
    <view class="address-box">
      <view class="address-none" v-if="!hasAddress" @tap="getAddress">
        <view>选择收货地址</view>
        <image
          src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-address-go.png"
        />
      </view>
      <view class="address-have" v-else @tap="getAddress">
        <view class="address-in">
          <view class="address-name">
            {{addressObj.userName}}
            <text>{{addressObj.telNumber}}</text>
          </view>
          <view
            class="address-info"
          >{{addressObj.provinceName}}{{addressObj.cityName}}{{addressObj.countyName}}{{addressObj.detailInfo}}</view>
        </view>
        <view class="address-go">
          <view>更改地址</view>
          <image
            src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-address-go.png"
          />
        </view>
      </view>
    </view>
    <view class="product-view">
      <view class="flex-row item-view" v-for="(item,key) in orderInfo.productList" :key="key">
        <image class="item-image" :src="item.img" mode="aspectFit" />
        <view class="flex-column">
          <view class="text-twice pro-name">{{item.name}}</view>
          <view class="flex-wrap"></view>
          <view class="flex-row price-score" style="width:100%">
            <image
              class="icon-coin"
              src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-icon-coin.png"
            />
            <view class="hkd-amount">
              <view v-if="item.integral" class="price-num">{{ item.integral }}</view>
              <image
                v-if="item.integral&&item.saleAmount"
                class="price-plus"
                src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-add-image.png"
              />
              <view v-if="item.saleAmount" class="price-amount">{{ item.saleAmount }}元</view>
            </view>
          </view>
        </view>
      </view>
    </view>
    <view class="flex-row footer" :class="isIpx ? 'isipx-view' : ''">
      <view class="flex-row price-score" style="width:auto">
        <image
          class="icon-coin"
          src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-icon-coin.png"
        />
        <view class="hkd-amount">
          <view v-if="orderInfo.integral" class="price-num">{{ orderInfo.integral }}</view>
          <image
            v-if="orderInfo.integral&&orderInfo.saleAmount"
            class="price-plus"
            src="https://traceability-1259661131.cos.ap-hongkong.myqcloud.com/image/mini-add-image.png"
          />
          <view v-if="orderInfo.saleAmount" class="price-amount">{{ orderInfo.saleAmount }}元</view>
        </view>
      </view>
      <view class="flex-wrap"></view>
      <text class="bottom-buy" @tap="submitClick">支付</text>
    </view>
  </view>
</template>
<script>
import { randomString } from '@/utils/format';
import md5 from '@/utils/md5';
export default {
  data() {
    return {
      orderInfo: {},
      // 地址有无的标识
      hasAddress: false,
      // 地址详细信息
      addressObj: undefined
    };
  },
  onLoad(option) {
    if (option && option.param) {
      this.param = JSON.parse(option.param);
      this.$store.dispatch('shopToken', this.param.shopToken);
      this.pageInit();
    }
  },
  methods: {
    // 查询商品信息
    pageInit() {
      this.$axios.post({
        url: '/order/detail',
        data: {
          productId: this.param.productId
        },
        addressFrom: 'h5'
      }).then(res => {
        this.orderInfo = res;
      }).catch(() => {
        setTimeout(() => {
          this.$uni.navigateBack();
        }, 1500);
      });
    },
    // 获取地址
    getAddress() {
      let _this = this;
      uni.chooseAddress({
        success(res) {
          _this.hasAddress = true;
          _this.addressObj = res;
        }
      });
    },
    // 支付
    submitClick() {
      if (!this.hasAddress) {
        this.$uni.showToast('请先选择一个收货地址');
        return;
      }
      // 下单
      this.$axios.post({
        url: `/order/`,
        data: {
          productId: this.param.productId,
          type: 10,
          deliveryMethod: '50',
          deliveryAddress: {
            consignee: this.addressObj.userName,
            phone: this.addressObj.telNumber,
            province: this.addressObj.provinceName,
            city: this.addressObj.cityName,
            area: this.addressObj.countyName,
            address: this.addressObj.detailInfo
          }
        },
        addressFrom: 'h5'
      }).then(res => {
        this.$axios.post({
          url: `/wx/order/pay`,
          data: {
            outTradeNo: res.id,
            total: this.orderInfo.saleAmount
          }
        }).then(res => {
          if (res && (res.code === '0' || res.code === 0)) {
            let paySign;
            // 生成签名
            // paySign = md5.hexMD5('appId=' + this.$store.getters.appid + '&nonceStr=' + randomString(32) + '&package=' + 'prepay_id=' + res.data + '&signType=MD5&timeStamp=' + Math.round(new Date().getTime() / 1000).toString()).toUpperCase();
            paySign = md5.hexMD5('appId=' + this.$store.getters.appid + '&timeStamp=' + Math.round(new Date().getTime() / 1000).toString() + '&nonceStr=' + randomString(32) + '&package=' + 'prepay_id=' + res.data).toUpperCase();
            // 支付
            uni.requestPayment({
              appid: this.$store.getters.appid,
              timeStamp: Math.round(new Date().getTime() / 1000).toString(),
              nonceStr: randomString(32),
              package: 'prepay_id=' + res.data,
              signType: 'MD5',
              paySign: paySign,
              success(res) {
                console.log(res);
              },
              fail(res) {
                console.log(res);
              }
            });
            return;
          }
          this.$uni.showToast(res.message);
        });
      });
    }
  }
};
</script>
<style lang="scss" scoped>
.address-box {
  width: calc(100% - 60rpx);
  height: auto;
  padding: 34rpx 30rpx;
  background: #f7e8e9;
  .address-none,
  .address-have {
    width: 100%;
    height: auto;
    display: flex;
    justify-content: space-between;
    align-items: center;
    view {
      font-size: 30rpx;
      font-weight: 400;
      color: #353535;
    }
    image {
      width: 17rpx;
      height: 30rpx;
    }
  }
  .address-have {
    .address-in {
      width: calc(100% - 150rpx);
      height: auto;
      display: flex;
      flex-direction: column;
      .address-name {
        width: 100%;
        font-size: 30rpx;
        font-weight: bold;
        color: #353535;
        display: block;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        text {
          font-weight: normal;
          font-size: 28rpx;
          margin-left: 10rpx;
        }
      }
      .address-info {
        font-size: 28rpx;
        font-weight: 400;
        color: #353535;
        width: 100%;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        margin-top: 10rpx;
      }
    }
    .address-go {
      width: 140rpx;
      height: auto;
      margin-left: 10rpx;
      display: flex;
      justify-content: space-between;
      align-items: center;
      view {
        font-size: 26rpx;
        font-weight: 400;
        color: #b91126;
      }
      image {
        width: 17rpx;
        height: 30rpx;
        margin-left: 10rpx;
      }
    }
  }
}
.product-view {
  padding: 30rpx 30rpx;
  background: white;
  // box-shadow: 0rpx 0rpx 10rpx 0rpx rgba(0, 0, 0, 0.3);
  position: relative;
  .item-view {
    width: 100%;
    padding: 20rpx 0;
    .item-image {
      width: 190rpx;
      height: 190rpx;
      margin: 0 20rpx;
      box-shadow: 0rpx 0rpx 10rpx 0rpx rgba(0, 0, 0, 0.3);
    }
    .flex-column {
      width: calc(100% - 230rpx);
      height: 210rpx;
      .pro-name {
        width: 100%;
        font-weight: 400;
        color: rgba(0, 0, 0, 1);
        font-size: 28rpx;
      }
    }
  }
  .account-inut {
    padding: 20rpx;
    margin-top: 30rpx;
    border: 2rpx solid rgba(204, 204, 204, 1);
    border-radius: 10rpx;
    font-size: 24rpx;
    color: #999;
    background: #f8f8f8;
  }
}
.footer {
  position: fixed;
  box-shadow: 0rpx 0rpx 20rpx 0rpx rgba(0, 0, 0, 0.3);
  .bottom-buy {
    padding: 16rpx 80rpx;
    background: #b91126;
    box-shadow: 0rpx 0rpx 10rpx 0rpx rgba(0, 0, 0, 0.3);
    font-weight: 400;
    color: rgba(255, 255, 255, 1);
    font-size: 28rpx;
  }
}
</style>
