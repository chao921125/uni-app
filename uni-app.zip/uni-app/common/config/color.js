// 部分js使用的颜色
export default {
	textLink: "#5677fc",
    colorPrimary: "#5677fc",
    backgroundPrimary: "#5677fc",
    textPrimary: "#5677fc",
    messageBtnConfirm: "#5677fc",
    messageBtnCancel: "#555",
    modalBtnConfirm: "#5677fc",
    modalBtnCancel: "#555",
};
