import NoData from "@/static/images/toast/img_nodata.png";
import UserAvatar from "@/static/images/my/user-avatar.png";
import PaySuccess from "@/static/images/mall/pay/icon_pay_weixin.png";

export default {
    NoData: NoData,
    UserAvatar: UserAvatar,
    PaySuccess: PaySuccess,
	getImg: (url) => {
		// const path = `../assets/images/home/${url}`;
		// const modules = import.meta.globEager("../assets/images/home/*");
		// return modules[path].default;
	}
}
